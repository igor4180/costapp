import CostItem from "./components/CostItem";

function App() {
  const items = [
    {
      date: new Date(2023,9,22,),
     description: "Очень нужное1",
     price:123
    },
    {
      date: new Date(2023,12,23,),
      description: "Очень нужное2",
      price:3455
    },
    {
      date: new Date(2023,11,23,),
      description: "Очень нужное3",
      price:4358
    }
  ];
  
  return (
    <div>
      <CostItem date={items[0].date} 
      description={items[0].description} 
      price={items[0].price} />
      <CostItem date={items[1].date} 
      description={items[1].description} 
      price={items[1].price} />
      <CostItem date={items[2].date} 
      description={items[2].description} 
      price={items[2].price} />
    </div>
  );
}

export default App;
