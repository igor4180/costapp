import './CostItem.css'

function CostItem(props){
	return (
        <div className="cost_item">
            <div>
                <div>{props.date.toLocaleString("ru-RU",{month:"long"})}</div>
                <div>{props.date.getFullYear()}</div>
                <div>{props.date.toLocaleString("ru-RU",{day:"2-digit"})}</div>
            </div>
        
        <h2>{props.description}</h2> 
        <div>{props.price}</div> 
    
        </div>
    )
}
export default CostItem;